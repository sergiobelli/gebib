package eu.sergiobelli.gebib.model.libri;

public class Libro {

}
