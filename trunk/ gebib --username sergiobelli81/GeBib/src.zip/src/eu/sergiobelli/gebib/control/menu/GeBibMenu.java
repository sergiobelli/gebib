package eu.sergiobelli.gebib.control.menu;

/**
 * 
 * @author S.BELLI
 *
 */
public class GeBibMenu {

	//Autori
	public String inserisciAutore() {return "inserisciAutore";}
	public String elencoAutori() {return "elencoAutori";}
	
	
	//Libri
	public String inserisciLibro() {return "inserisciLibro";}
	public String elencoLibri() {return "elencoLibri";}	
	
	
	//Properties
	public String inserisciProperties() {return "inserisciProperties";}
	public String elencoProperties() {return "elencoProperties";}

	//Report
	public String generaReport() {return "generaReport";}
	
}
