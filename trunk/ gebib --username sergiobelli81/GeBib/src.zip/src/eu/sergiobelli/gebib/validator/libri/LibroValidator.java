package eu.sergiobelli.gebib.validator.libri;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import eu.sergiobelli.asserts.Assert;

public class LibroValidator {

	protected static final ResourceBundle bundle = ResourceBundle.getBundle("eu.sergiobelli.gebib.validator.libri.messages");
	
	public void validateTitolo(FacesContext facesContext, UIComponent uiComponent, Object obj) throws ValidatorException {
		validateTitolo(obj);
	}
	public void validateTitolo(Object obj) throws ValidatorException {
				
		if (Assert.isNull(obj)
				|| (Assert.isEmpty(obj.toString()))) {
			
			throw new ValidatorException(
					new FacesMessage(
							FacesMessage.SEVERITY_ERROR, 
							bundle.getString("libro.nonvalido"), 
							bundle.getString("libro.nonvalido.titolo.vuotoOnullo")));
			
		} else {
			String cognome = obj.toString();
			
			if (cognome.length() > 255) {
				
				throw new ValidatorException(
						new FacesMessage(
								FacesMessage.SEVERITY_ERROR, 
								bundle.getString("libro.nonvalido"), 
								bundle.getString("libro.nonvalido.titolo.lunghezzaMassimaSuperata")));
				
			}
		}

	}
	
	public void validateIsbn(FacesContext facesContext, UIComponent uiComponent, Object obj) throws ValidatorException {
		validateIsbn(obj);
	}
	public void validateIsbn(Object obj) throws ValidatorException {
				
		if (Assert.isNull(obj)
				|| (Assert.isEmpty(obj.toString()))) {
			
			throw new ValidatorException(
					new FacesMessage(
							FacesMessage.SEVERITY_ERROR, 
							bundle.getString("libro.nonvalido"), 
							bundle.getString("libro.nonvalido.isbn.vuotoOnullo")));
			
		} else {
			String cognome = obj.toString();
			
			if (cognome.length() > 17) {
				
				throw new ValidatorException(
						new FacesMessage(
								FacesMessage.SEVERITY_ERROR, 
								bundle.getString("libro.nonvalido"), 
								bundle.getString("libro.nonvalido.isbn.lunghezzaMassimaSuperata")));
				
			}
		}

	}
}