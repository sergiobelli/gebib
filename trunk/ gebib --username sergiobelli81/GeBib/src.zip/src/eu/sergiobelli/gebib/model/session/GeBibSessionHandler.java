package eu.sergiobelli.gebib.model.session;

import javax.faces.context.FacesContext;

import eu.sergiobelli.asserts.Assert;

public class GeBibSessionHandler {

	public static GeBibSession getGeBibSession() {
		
		GeBibSession geBibSession = (GeBibSession) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("GeBibSession");
		
		if (Assert.isNull(geBibSession)) {
			geBibSession = new GeBibSession();
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("GeBibSession", geBibSession);
		}

		return geBibSession;

	}
}
