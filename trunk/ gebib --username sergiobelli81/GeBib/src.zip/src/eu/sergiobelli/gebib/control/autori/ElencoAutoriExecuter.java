package eu.sergiobelli.gebib.control.autori;

import java.util.List;

import eu.sergiobelli.gebib.exception.GeBibException;
import eu.sergiobelli.gebib.model.orm.dao.AutoriDao;
import eu.sergiobelli.gebib.model.orm.data.Autori;



public class ElencoAutoriExecuter {

	public ElencoAutoriExecuter() {
		try {
			autori = AutoriDao.getInstance().list();
		} catch (GeBibException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private List<Autori> autori = null;
	public List<Autori> getAutori() {
		return autori;
	}
	public void setAutori(List<Autori> autori) {
		this.autori = autori;
	}
	
}
