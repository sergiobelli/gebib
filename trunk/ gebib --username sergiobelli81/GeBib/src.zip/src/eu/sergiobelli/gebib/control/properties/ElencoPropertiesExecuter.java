package eu.sergiobelli.gebib.control.properties;

import java.util.List;

import eu.sergiobelli.gebib.exception.GeBibException;
import eu.sergiobelli.gebib.model.orm.dao.PropertiesDao;
import eu.sergiobelli.gebib.model.orm.data.Properties;

public class ElencoPropertiesExecuter {

	public ElencoPropertiesExecuter() {
		try {
			properties = PropertiesDao.getInstance().list();
		} catch (GeBibException e) {
			e.printStackTrace();
		}
		
	}
	
	private List<Properties> properties = null;
	public List<Properties> getProperties() {
		return properties;
	}
	public void setProperties(List<Properties> properties) {
		this.properties = properties;
	}
	
}
