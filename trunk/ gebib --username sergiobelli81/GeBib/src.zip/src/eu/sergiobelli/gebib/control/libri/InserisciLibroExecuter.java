package eu.sergiobelli.gebib.control.libri;

import java.util.List;

import javax.faces.model.SelectItem;

import eu.sergiobelli.gebib.model.orm.dao.AutoriDao;
import eu.sergiobelli.gebib.model.orm.dao.LibriDao;
import eu.sergiobelli.gebib.model.orm.data.Autori;
import eu.sergiobelli.gebib.model.orm.data.Libri;
import eu.sergiobelli.asserts.Assert;
import eu.sergiobelli.gebib.util.logger.GeBibLogger;

public class InserisciLibroExecuter {

	protected String titolo;
	public String getTitolo() {return titolo;}
	public void setTitolo(String titolo) {this.titolo = titolo;}

	protected String isbn;
	public String getIsbn() {return isbn;}
	public void setIsbn(String isbn) {this.isbn = isbn;}
	
	protected Long autore;
	public Long getAutore() { return autore; }
	public void setAutore(Long autore) { this.autore = autore; }

	protected SelectItem[] autori;
	public SelectItem[] getAutori() { return autori; }
	public void setAutori(SelectItem[] autori) { this.autori = autori; }
	
	public InserisciLibroExecuter () {
		
		try {
			
			List<Autori> autors = AutoriDao.getInstance().list();
			if (Assert.isNotNull(autors)) {
				autori = new SelectItem[autors.size()];
				int i = 0;
				for (Autori autor : autors) {
					autori[i] = new SelectItem(String.valueOf(autor.getId()), autor.getCognome()+", "+autor.getNome());
					i++;
				}	
			}
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	public String salva () {
		
		String redirect = "elencoLibri";
		try {
			
			Libri libro = new Libri();
			libro.setTitolo(titolo);
			libro.setIsbn(isbn);
			libro.setAutore(AutoriDao.getInstance().get(this.autore.intValue()));
			
			LibriDao.getInstance().insert(libro);
			
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			redirect = "null";
		}
		
		return redirect;
	}
	
	private final GeBibLogger logger = new GeBibLogger(this.getClass().getName());
	
}
