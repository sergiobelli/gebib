package eu.sergiobelli.gebib.model.autori;

public class Autore {

	private String nome = null;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	private String cognome = null;
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
		
}
