package eu.sergiobelli.gebib.validator.autori;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import eu.sergiobelli.asserts.Assert;

public class AutoreValidator {
	protected static final ResourceBundle bundle = ResourceBundle.getBundle("eu.sergiobelli.gebib.validator.autori.messages");
	
	public void validateCognome(FacesContext facesContext, UIComponent uiComponent, Object obj) throws ValidatorException {
				
		if (Assert.isNull(obj)
				|| (Assert.isEmpty(obj.toString()))) {
			
			throw new ValidatorException(
					new FacesMessage(
							FacesMessage.SEVERITY_ERROR, 
							bundle.getString("autore.nonvalido"), 
							bundle.getString("autore.nonvalido.cognome.vuotoOnullo")));
			
		} else {
			String cognome = obj.toString();
			
			if (cognome.length() > 255) {
				
				throw new ValidatorException(
						new FacesMessage(
								FacesMessage.SEVERITY_ERROR, 
								bundle.getString("autore.nonvalido"), 
								bundle.getString("autore.nonvalido.cognome.lunghezzaMassimaSuperata")));
				
			}
		}

	}}