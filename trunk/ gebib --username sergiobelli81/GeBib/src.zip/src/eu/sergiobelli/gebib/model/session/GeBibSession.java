package eu.sergiobelli.gebib.model.session;

import eu.sergiobelli.gebib.model.libri.Libri;

public class GeBibSession {

	private Libri libri = null;

	public Libri getLibri() {
		return libri;
	}

	public void setLibri(Libri libri) {
		this.libri = libri;
	}
	
}
