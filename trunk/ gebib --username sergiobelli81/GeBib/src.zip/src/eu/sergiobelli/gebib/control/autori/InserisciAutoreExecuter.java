package eu.sergiobelli.gebib.control.autori;

import eu.sergiobelli.gebib.model.orm.dao.AutoriDao;
import eu.sergiobelli.gebib.model.orm.data.Autori;
import eu.sergiobelli.gebib.util.logger.GeBibLogger;

public class InserisciAutoreExecuter {

	private String cognome = "";
	public String getCognome() {return cognome;}
	public void setCognome(String cognome) {this.cognome = cognome;}

	private String nome = "";
	public String getNome() {return nome;}
	public void setNome(String nome) {this.nome = nome;}
	
	public String salva () {
		
		String redirect = "elencoAutori";
		try {
			
			Autori autore = new Autori();
			autore.setCognome(cognome);
			autore.setNome(nome);
			
			AutoriDao.getInstance().insert(autore);
			
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			redirect = "null";
		}
		
		return redirect;
	}
	
	private final GeBibLogger logger = new GeBibLogger(this.getClass().getName());

}
