package eu.sergiobelli.gebib.model.libri;

import java.util.List;

public class Libri {

	List<Libro> libri = null;

	public List<Libro> getLibri() {
		return libri;
	}

	public void setLibri(List<Libro> libri) {
		this.libri = libri;
	}
	
}
