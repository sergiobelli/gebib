package eu.sergiobelli.gebib.model.autori;

import java.util.List;

public class Autori {

	List<Autore> autori = null;

	public List<Autore> getAutori() {
		return autori;
	}

	public void setAutori(List<Autore> autori) {
		this.autori = autori;
	}
	
}
